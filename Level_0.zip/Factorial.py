#Programmer: Kerwin Rounds Jr
#Program 3
#1/12/18


while i in range(0,51){
    if i / 2
    print(i);
}
